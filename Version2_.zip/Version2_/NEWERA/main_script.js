// Function to open the modal and display the CV
function openCVModal(cvURL) {
    const modal = document.getElementById('cvModal');
    const cvFrame = document.getElementById('cvFrame');
    
    // Set the src of the iframe to the CV URL
    cvFrame.src = cvURL;
    
    // Display the modal
    modal.style.display = 'block';
}

// Function to close the modal
function closeCVModal() {
    const modal = document.getElementById('cvModal');
    modal.style.display = 'none';
    
    // Clear the iframe src to stop loading the PDF
    const cvFrame = document.getElementById('cvFrame');
    cvFrame.src = '';
}

// Event listener to close the modal when the close button is clicked
document.querySelector('.modal .close').addEventListener('click', closeCVModal);

// Event listener to close the modal when clicking outside the modal content
window.onclick = function(event) {
    const modal = document.getElementById('cvModal');
    if (event.target == modal) {
        closeCVModal();
    }
};

// Function to render a single card dynamically
function renderCard(profile) {
    // Choose the correct profile icon based on gender
    const profilePic = profile.gender === "Male" ? "img/man.png" : "img/Female.png";

    const card = document.createElement("div");
    card.className = `profile-card ${profile.gender === "Female" ? "female" : ""}`;
    
    // Add card content (image, details, and actions)
    card.innerHTML = `
        <div class="profile-header">
            <div class="profile-img">
                <img src="${profilePic}" alt="Profile Picture">
            </div>
            <h3>${profile.name}</h3>
        </div>
        <div class="profile-details">
            <p>Country: ${profile.nationality}</p> <!-- Added country field -->
            <p>Major: ${profile.major}</p>
            <p>CX: ${profile.cx}</p>
            <p>GPA: ${profile.gpa}</p>
            <p>M-GPA: ${profile.mgpa}</p> <!-- Ensure M-GPA is displayed -->
            <p>Degree: ${profile.degree}</p>
        </div>
        <div class="profile-actions">
            <button class="preview-btn" data-cv-url="${profile.cv}">Preview</button>
            <button class="offer-btn">Offer</button>
            <a href="${profile.cv}" class="download-cv" download="CV_${profile.name}.pdf">
                <img src="img/download-icon.png" alt="Download CV" class="download-icon">
            </a>
        </div>
    `;
    return card;
}

// Function to load all profiles from localStorage and render them
function loadProfiles() {
    const profileContainer = document.getElementById("profile-cards");

    // Get profiles from localStorage
    const profiles = JSON.parse(localStorage.getItem('profiles')) || [];

    profiles.forEach(profile => {
        const card = renderCard(profile);
        profileContainer.appendChild(card);
    });

    attachPreviewEventListeners(); // Attach event listeners to the preview buttons after rendering profiles
}

// Function to add click event listeners to all preview buttons
function attachPreviewEventListeners() {
    const previewButtons = document.querySelectorAll('.preview-btn');
    
    previewButtons.forEach(button => {
        button.addEventListener('click', function() {
            const cvURL = button.getAttribute('data-cv-url');
            openCVModal(cvURL); // Open the modal with the CV URL
        });
    });
}

// Function to filter and display profiles based on user input
function filterProfiles() {
    const genderFilter = document.getElementById("gender-filter").value;
    const majorFilter = document.getElementById("major-filter").value.toLowerCase();
    const gpaFilter = document.getElementById("gpa-filter").value;
    const mgpaFilter = document.getElementById("mgpa-filter").value;
    const degreeFilter = document.getElementById("degree-filter").value;

    const profileContainer = document.getElementById("profile-cards");
    profileContainer.innerHTML = ''; // Clear the current profiles

    // Get profiles from localStorage
    const profiles = JSON.parse(localStorage.getItem('profiles')) || [];

    profiles.forEach(profile => {
        let match = true;

        // Filter by gender
        if (genderFilter && profile.gender !== genderFilter) {
            match = false;
        }

        // Filter by major (case-insensitive)
        if (majorFilter && !profile.major.toLowerCase().includes(majorFilter)) {
            match = false;
        }

        // Filter by GPA
        if (gpaFilter && profile.gpa < gpaFilter) {
            match = false;
        }

        // Filter by M-GPA
        if (mgpaFilter && profile.mgpa < mgpaFilter) {
            match = false;
        }

        // Filter by degree
        if (degreeFilter && profile.degree !== degreeFilter) {
            match = false;
        }

        if (match) {
            const card = renderCard(profile);
            profileContainer.appendChild(card);
        }
    });

    attachPreviewEventListeners(); // Re-attach event listeners after filtering
}

// Function to handle form submission and add the new profile card
function submitProfile() {
    const profile = {
        name: document.getElementById("name").value,
        gender: document.getElementById("gender").value,
        major: document.getElementById("major").value,
        cx: document.getElementById("cx").value,
        nationality: document.getElementById("nationality").value, // Collect nationality
        gpa: document.getElementById("gpa").value,
        mgpa: document.getElementById("mgpa").value, // Collect M-GPA
        degree: document.getElementById("degree").value,
        cv: "" // Placeholder for CV URL or filename, you can modify it accordingly
    };

    // Add the new card
    const profileContainer = document.getElementById("profile-cards");
    const card = renderCard(profile);
    profileContainer.appendChild(card);

    // Optionally, save to localStorage or a database
    let profiles = JSON.parse(localStorage.getItem('profiles')) || [];
    profiles.push(profile);
    localStorage.setItem('profiles', JSON.stringify(profiles));

    attachPreviewEventListeners(); // Attach event listener to the new card's preview button
}

// Call loadProfiles when the page loads
window.onload = function() {
    loadProfiles(); // Load profiles from local storage or database
};
