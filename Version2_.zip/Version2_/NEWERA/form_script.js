// Function to handle form submission
function submitCV(event) {
    event.preventDefault(); // Prevent page reload on form submission

    // Get form data
    const studentProfile = {
        name: document.getElementById('name').value,
        gender: document.getElementById('gender').value,
        major: document.getElementById('major').value,
        nationality: document.getElementById('nationality').value,
        cx: document.getElementById('cx').value, // Get the CX field
        gpa: document.getElementById('gpa').value,
        mgpa: document.getElementById('mgpa').value,
        degree: document.getElementById('degree').value,
        cv: '' // Placeholder for CV URL or filename
    };

    // Get the uploaded file (CV)
    const cvFile = document.getElementById('cv-file').files[0];
    
    // Store the file and get the URL (we'll use localStorage for this example, but this is where you'd upload to Firebase)
    if (cvFile) {
        const fileReader = new FileReader();
        fileReader.onload = function(event) {
            // Save the CV file content as a data URL in localStorage (you should upload this file to Firebase instead)
            studentProfile.cv = event.target.result;

            // Store the profile in localStorage
            saveProfile(studentProfile);
        };
        fileReader.readAsDataURL(cvFile); // This encodes the file as a base64 URL
    }
}

// Function to save the profile in localStorage
function saveProfile(profile) {
    let profiles = JSON.parse(localStorage.getItem('profiles')) || [];
    profiles.push(profile);
    localStorage.setItem('profiles', JSON.stringify(profiles));

    // Redirect to the main page after submission
    window.location.href = 'index.html';
}
